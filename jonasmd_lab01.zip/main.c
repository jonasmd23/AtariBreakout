#include <stdio.h>
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

#include "lcd.h"
#include "pac.h"

static const char *TAG = "lab01";

#define DELAY_MS(ms) \
	vTaskDelay(((ms)+(portTICK_PERIOD_MS-1))/portTICK_PERIOD_MS)

//----------------------------------------------------------------------------//
// Car Implementation - Begin
//----------------------------------------------------------------------------//

// Car constants
#define CAR_CLR rgb565(220,30,0)
#define WINDOW_CLR rgb565(180,210,238)
#define TIRE_CLR BLACK
#define HUB_CLR GRAY

// TODO: Finish car part constants
#define CAR_W 60
#define CAR_H 32

#define BODY_X0 0
#define BODY_Y0 12
#define BODY_X1 59
#define BODY_Y1 24 
#define TIRE_S 7
#define TIRE_C0 11
#define TIRE_C1 48
#define HUB_S 4
#define BODY_S 1
#define WINDOW_H 8
#define WINDOW_R 2
#define SCOOT 3
#define TRIANGLE_B 40
#define TRIANGLE_T 9
#define WINDOW2 37
#define BODY_X3 39
#define WINDOW_W 18
#define WINDO 21

/**
 * @brief Draw a car at the specified location.
 * @param x      Top left corner X coordinate.
 * @param y      Top left corner Y coordinate.
 * @details Draw the car components relative to the anchor point (top, left).
 */
void drawCar(coord_t x, coord_t y)
{
	// TODO: Implement car procedurally with lcd geometric primitives.*************************************
	lcd_fillRect2(x, y+BODY_Y0, x+BODY_X1, y+BODY_Y1, CAR_CLR);
	lcd_fillRect2(x+BODY_S, y, x+BODY_X3, y+BODY_Y1, CAR_CLR);
	lcd_fillTriangle(x+TRIANGLE_B, y+TRIANGLE_T, x+TRIANGLE_B, y+TIRE_C0, x+BODY_X1, y+TIRE_C0, CAR_CLR);
	lcd_fillCircle(x+TIRE_C0, y+BODY_Y1, TIRE_S, TIRE_CLR);
	lcd_fillCircle(x+TIRE_C0, y+BODY_Y1, HUB_S, HUB_CLR);
	lcd_fillCircle(x+TIRE_C1, y+BODY_Y1, TIRE_S, TIRE_CLR);
	lcd_fillCircle(x+TIRE_C1, y+BODY_Y1, HUB_S, HUB_CLR);
	lcd_fillRoundRect2(x+SCOOT, y+BODY_S, x+WINDOW_W, y+WINDOW_H, WINDOW_R, WINDOW_CLR);
	lcd_fillRoundRect2(x+WINDO, y+BODY_S, x+WINDOW2, y+WINDOW_H, WINDOW_R, WINDOW_CLR);
}

//----------------------------------------------------------------------------//
// Car Implementation - End
//----------------------------------------------------------------------------//

// Main display constants
#define BACKGROUND_CLR rgb565(0,60,90)
#define TITLE_CLR GREEN
#define STATUS_CLR WHITE
#define STR_BUF_LEN 12 // string buffer length
#define FONT_SIZE 2
#define FONT_W (LCD_CHAR_W*FONT_SIZE)
#define FONT_H (LCD_CHAR_H*FONT_SIZE)
#define STATUS_W (FONT_W*3)

#define WAIT 2000 // milliseconds
#define DELAY_EX3 20 // milliseconds

// Object position and movement
#define OBJ_X 100
#define OBJ_Y 100
#define OBJ_MOVE 3 // pixels
#define YELLOW rgb565(255, 255, 0)


// Application main
void app_main(void)
{
	ESP_LOGI(TAG, "Start up");
	lcd_init();
	lcd_fillScreen(BACKGROUND_CLR);
	lcd_setFontSize(FONT_SIZE);
	lcd_drawString(0, 0, "Hello World! (lcd)", TITLE_CLR);
	printf("Hello World! (terminal)\n");
	DELAY_MS(2000);

	// TODO: Exercise 1 - Draw car in one location.
	lcd_fillScreen(BACKGROUND_CLR);
	lcd_drawString(0, 0, "Exercise 1", TITLE_CLR);
	drawCar(OBJ_X, OBJ_Y);
	DELAY_MS(2000);

	// TODO: Exercise 2 - Draw moving car (Method 1), one pass across display.
	// Clear the entire display and redraw all objects each iteration.
	// Use a loop and increment x by OBJ_MOVE each iteration.
	// Start x off screen (negative coordinate).
	for (coord_t x= -CAR_W; x<= LCD_W; x+= OBJ_MOVE)
	{
		lcd_fillScreen(BACKGROUND_CLR);
		lcd_drawString(0, 0, "Exercise 2", TITLE_CLR);
		drawCar(x, OBJ_Y); 
    	char str[12];
    	sprintf(str, "%3ld", x);
    	lcd_drawString(0, 225, str, STATUS_CLR);
	}



	// TODO: Exercise 3 - Draw moving car (Method 2), one pass across display.
	// Move by erasing car at old position, then redrawing at new position.
	// Objects that don't change or move are drawn once.
	lcd_fillScreen(BACKGROUND_CLR);
	lcd_drawString(0, 0, "Exercise 3", TITLE_CLR);
	for (coord_t x= -CAR_W; x<= LCD_W; x+= OBJ_MOVE)
	{
		lcd_fillRect2(x-OBJ_MOVE, OBJ_Y, x+CAR_W, OBJ_Y+CAR_H, BACKGROUND_CLR);
		drawCar(x, OBJ_Y);
		lcd_fillRect2(0, 225, 40, 240, BACKGROUND_CLR);
		char str[12];
    	sprintf(str, "%3ld", x);
    	lcd_drawString(0, 225, str, STATUS_CLR);
		DELAY_MS(20);
	}





	// TODO: Exercise 4 - Draw moving car (Method 3), one pass across display.
	// First, draw all objects into a cleared, off-screen frame buffer.
	// Then, transfer the entire frame buffer to the screen.
	lcd_frameEnable(); 
	lcd_getFrameBuffer();
	for (coord_t x= -CAR_W; x<= LCD_W; x+= OBJ_MOVE)
	{
		lcd_fillScreen(BACKGROUND_CLR);
		lcd_drawString(0, 0, "Exercise 4", TITLE_CLR);
		drawCar(x, OBJ_Y);
		char str[12];
    	sprintf(str, "%3ld", x);
    	lcd_drawString(0, 225, str, STATUS_CLR);
		lcd_writeFrame();
	}
	lcd_frameDisable();


	// TODO: Exercise 5 - Draw an animated Pac-Man moving across the display.
	// Use Pac-Man sprites instead of the car object.
	// Cycle through each sprite when moving the Pac-Man character.
	uint16_t i = 0;
	const uint8_t pidx[] = {0, 1, 2, 1};
	lcd_frameEnable(); 
	lcd_getFrameBuffer();
	for(;;)
	{
		for (coord_t x= -CAR_W; x<= LCD_W; x+= OBJ_MOVE)
		{
			lcd_fillScreen(BACKGROUND_CLR);
			lcd_drawString(0, 0, "Exercise 5", TITLE_CLR);
			lcd_drawBitmap (x, OBJ_Y, pac[pidx[i++ % sizeof(pidx)]], PAC_W, PAC_H, YELLOW);
			char str[12];
			sprintf(str, "%3ld", x);
			lcd_drawString(0, 225, str, STATUS_CLR);
			lcd_writeFrame();
		}
		}	
		lcd_frameDisable();
}
