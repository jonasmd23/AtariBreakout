#include <stdio.h>
#include <stdlib.h>  // rand
#include <stdbool.h>
#include <stdint.h>

#include "hw.h"
#include "lcd.h"
#include "cursor.h"
#include "sound.h"
#include "pin.h"
#include "missile.h"
#include "plane.h"
#include "game.h"
#include "config.h"

#define FIVE   5
#define TWENTY 20

// States for the plane state machine.
enum plane_st_t {
    init_st,    
    idle_st,    
    flying_st   
};

static enum plane_st_t currentState = init_st;
static missile_t *plane_m = NULL; 

static coord_t plane_x = 0;
static coord_t plane_y = 0;
static int8_t direction = 1; 
static uint32_t idle_timer = 0;
static bool missile_launched = false;

/*helper to draw the plane*/
static void plane_draw(color_t color) {
    coord_t x0, y0, x1, y1, x2, y2;
    //movement
    if (direction > 0) {
        x0 = plane_x;                 
        y0 = plane_y;
        x1 = plane_x - CONFIG_PLANE_WIDTH;   
        y1 = plane_y - (CONFIG_PLANE_HEIGHT / 2);
        x2 = plane_x - CONFIG_PLANE_WIDTH;   
        y2 = plane_y + (CONFIG_PLANE_HEIGHT / 2);
    } else {
        x0 = plane_x;                 
        y0 = plane_y;
        x1 = plane_x + CONFIG_PLANE_WIDTH;   
        y1 = plane_y - (CONFIG_PLANE_HEIGHT / 2);
        x2 = plane_x + CONFIG_PLANE_WIDTH;   
        y2 = plane_y + (CONFIG_PLANE_HEIGHT / 2);
    }
    lcd_fillTriangle(x0, y0, x1, y1, x2, y2, color);
}

/******************** Plane Init Function ********************/
void plane_init(missile_t *m) {
    plane_m = m;
    currentState = init_st;
    plane_x = 0;
    plane_y = LCD_H / FIVE;  
    direction = 1;
    idle_timer = 0;
    missile_launched = false;
}

/******************** Plane Control Function ********************/
void plane_explode(void) {
    if (currentState == flying_st && plane_m != NULL) {
        //missile_explode(plane_m);
        currentState = idle_st;
        plane_draw(CONFIG_COLOR_BACKGROUND); 
        idle_timer = 0;
    }
}

/******************** Plane Status Functions ********************/
void plane_get_pos(coord_t *x, coord_t *y) {
    if (!x || !y) return;
    *x = plane_x;
    *y = plane_y;
}

/*if plane is flying or not*/
bool plane_is_flying(void) {
    return (currentState == flying_st);
}


/******************** Plane Tick Function ********************/
void plane_tick(void) {
    // ---------- State Transitions ----------
    switch (currentState) {
        case init_st:
            currentState = idle_st;
            idle_timer = 0;
            break;

        case idle_st:
            // Wait for the specified interval before spawning plane
            if (idle_timer >= CONFIG_PLANE_IDLE_TIME_TICKS) {
                plane_x = LCD_W - 1;
                plane_y = LCD_H / FIVE;
                direction = -1; 
                missile_launched = false;
                currentState = flying_st;
            }
            break;

        case flying_st:
            if (plane_x <= -CONFIG_PLANE_WIDTH || plane_x  >= LCD_W) {
                currentState = idle_st;
                idle_timer = 0;
            }
            break;

        default:
            break;
    }

    // ---------- State Actions ----------
    switch (currentState) {
        case init_st:
            break;

        case idle_st:
            idle_timer++;
            break;

        case flying_st:
            plane_draw(CONFIG_COLOR_BACKGROUND);

            plane_x += direction * CONFIG_PLANE_DISTANCE_PER_TICK;

            if (!missile_launched && plane_m != NULL) {
                if (plane_x <= (LCD_W / 2) + TWENTY && plane_x >= (LCD_W / 2) - TWENTY) {
                    missile_launch_plane(plane_m, plane_x, plane_y);
                    missile_launched = true;
                }
            }

            if (plane_x > -CONFIG_PLANE_WIDTH && plane_x < LCD_W) {
                plane_draw(CONFIG_COLOR_PLANE);
            } else {
            }
            break;

        default:
            break;
    }
}