#include <stdio.h>
#include <stdlib.h> // rand
#include <inttypes.h> // For PRIu32

#include "hw.h"
#include "lcd.h"
#include "cursor.h"
#include "sound.h"
#include "pin.h"
#include "missile.h"
#include "plane.h"
#include "game.h"
#include "config.h"

// sound support
#include "missileLaunch.h"

// M2: Define stats constants
#define STATS_Y 10
#define SHOTS_X 10
#define IMPACTED_X 200
#define SOUND_VOLUME 50
#define BIG 32

// All missiles
missile_t missiles[CONFIG_MAX_TOTAL_MISSILES];

// Alias into missiles array
missile_t *enemy_missiles = missiles+0;
missile_t *player_missiles = missiles+CONFIG_MAX_ENEMY_MISSILES;
missile_t *plane_missile = missiles+CONFIG_MAX_ENEMY_MISSILES+
									CONFIG_MAX_PLAYER_MISSILES;

// M2: Declare stats variables
uint32_t shots = 0;
uint32_t impacted = 0;

// Button state tracking for debouncing
static bool pressed = false;



// Initialize the game control logic.
// This function initializes all missiles, planes, stats, etc.
void game_init(void)
{
	// Initialize missiles
	for (uint32_t i = 0; i < CONFIG_MAX_TOTAL_MISSILES; i++)
		missile_init(missiles+i);

	// Initialize plane
	plane_init(plane_missile);

	// M2: Initialize stats
	shots = 0;
	impacted = 0;
	
	// Initialize button state
	pressed = false;

	// M2: Set sound volume
	sound_set_volume(SOUND_VOLUME);
}

// Update the game control logic.
// This function calls the missile & plane tick functions, relaunches
// idle enemy missiles, handles button presses, launches player missiles,
// detects collisions, and updates statistics.
void game_tick(void)
{
	// Tick missiles in one batch
	for (uint32_t i = 0; i < CONFIG_MAX_TOTAL_MISSILES; i++){
		missile_tick(missiles+i);
	}

	// Tick plane
	plane_tick();

	// Relaunch idle enemy missiles
	for (uint32_t i = 0; i < CONFIG_MAX_ENEMY_MISSILES; i++){
		if (missile_is_idle(enemy_missiles+i))
			missile_launch_enemy(enemy_missiles+i);
	}

	// M2: Check for button press. If so, launch a free player missile.
	coord_t x, y;
	uint64_t btns;
	btns = ~pin_get_in_reg() & HW_BTN_MASK;
	if (!pressed && btns) {
		pressed = true; // button pressed
		cursor_get_pos(&x, &y);
		// Check to see if a player missile is idle and launch it
		for (uint32_t i = 0; i < CONFIG_MAX_PLAYER_MISSILES; i++) {
			if (missile_is_idle(player_missiles+i)) {
				missile_launch_player(player_missiles+i, x, y);
				sound_start(missileLaunch, MISSILELAUNCH_SAMPLE_RATE, false);
				shots++;
				break;
			}
		}
	} else if (pressed && !btns) {
		pressed = false; // all released
	}

	// M2: Check for moving non-player missile collision with an explosion.
	for (uint32_t i = 0; i < CONFIG_MAX_TOTAL_MISSILES; i++) {
		missile_t *m = missiles + i;
		
		// Skip if this missile is not moving or is a player missile
		if (!missile_is_moving(m) || (m >= player_missiles && m < plane_missile))
			continue;
			
		coord_t m_x, m_y;
		missile_get_pos(m, &m_x, &m_y);
		
		// Check collision with all exploding missiles
		for (uint32_t j = 0; j < CONFIG_MAX_TOTAL_MISSILES; j++) {
			missile_t *exp = missiles + j;
			
			if (!missile_is_exploding(exp))
				continue;
				
			if (missile_is_colliding(exp, m_x, m_y)) {
				missile_explode(m);
				break;  // Missile already exploded
			}
		}
	}

	// M2: Check for flying plane collision with an explosion.
	if (plane_is_flying()){
		coord_t plane_x, plane_y;
		plane_get_pos(&plane_x, &plane_y);
		//
		for (uint32_t i = 0; i < CONFIG_MAX_TOTAL_MISSILES; i++) {
			missile_t *exp = missiles + i;
			
			if (!missile_is_exploding(exp))
				continue;
				
			if (missile_is_colliding(exp, plane_x, plane_y)) {
				plane_explode();
				break;
			}
		}
	}
	
	// M2: Count impacted enemy missiles
	for (uint32_t i = 0; i < CONFIG_MAX_ENEMY_MISSILES; i++) {
		if (missile_is_impacted(enemy_missiles+i)) {
			impacted++;
		}
	}
	// Also check plane missile if it impacted
	if (missile_is_impacted(plane_missile)) {
		impacted++;
	}
	// M2: Draw stats
    char text_buffer[BIG];
	// Draw shots count
	snprintf(text_buffer, sizeof(text_buffer), "Shots: %" PRIu32, shots);
	lcd_drawString(SHOTS_X, STATS_Y, text_buffer, CONFIG_COLOR_STATUS);
	// Draw impacted count
	snprintf(text_buffer, sizeof(text_buffer), "Impacted: %" PRIu32, impacted);
	lcd_drawString(IMPACTED_X, STATS_Y, text_buffer, CONFIG_COLOR_STATUS); 

}