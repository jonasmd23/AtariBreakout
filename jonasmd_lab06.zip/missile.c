#include <stdio.h>
#include <stdlib.h>     // rand
#include <stdbool.h>
#include <stdint.h>
#include <math.h>       // sqrtf

#include "hw.h"
#include "lcd.h"
#include "cursor.h"
#include "sound.h"
#include "pin.h"
#include "missile.h"
#include "plane.h"
#include "game.h"
#include "config.h"

#define THREE     3
#define FIVE      5
#define SIX       6
#define THOUSAND  1000

// Missile internal states
enum missile_st_t {
    init_st,
    idle_st,
    moving_st,
    exploding_grow_st,
    exploding_shrink_st,
    impact_st
};

/************************ Initialization *************************/
void missile_init(missile_t *m) {
    if (!m) return;
    m->type = MISSILE_TYPE_PLAYER;
    m->currentState = init_st;
    m->x_origin = 0;
    m->y_origin = 0;
    m->x_dest = 0;
    m->y_dest = 0;
    m->total_length = 0;
    m->x_current = 0;
    m->y_current = 0;
    m->length = 0;
    m->launch = false;
    m->explode_me = false;
    m->radius = 0;
}

/************************ Launch Functions *************************/

// Pick nearest silo and start player missile
void missile_launch_player(missile_t *m, coord_t x_dest, coord_t y_dest) {
    if (!m) return;

    m->type = MISSILE_TYPE_PLAYER;
    m->x_dest = x_dest;
    m->y_dest = y_dest;

    if (x_dest < (LCD_W / THREE)) {
        m->x_origin = LCD_W / SIX;                
    } else if (x_dest < (2 * LCD_W / THREE)) {
        m->x_origin = LCD_W / 2;                    
    } else {
        m->x_origin = (FIVE * LCD_W) / SIX;         
    }

    m->y_origin = LCD_H - 1;

    m->x_current = m->x_origin;
    m->y_current = m->y_origin;
    m->length = 0;
    m->radius = 0;
    m->explode_me = false;
    m->launch = true;

    int32_t dx = m->x_dest - m->x_origin;
    int32_t dy = m->y_dest - m->y_origin;
    m->total_length = (int32_t)sqrtf((float)(dx * dx + dy * dy));
    if (m->total_length <= 0) m->total_length = 1;

    m->currentState = moving_st;
}

/*get position for and set to launch enemy*/
void missile_launch_enemy(missile_t *m) {
    if (!m) return;

    m->type = MISSILE_TYPE_ENEMY;
    m->x_origin = rand() % LCD_W;
    m->y_origin = 0;
    m->x_dest = rand() % LCD_W;
    m->y_dest = LCD_H - 1;

    m->x_current = m->x_origin;
    m->y_current = m->y_origin;
    m->length = 0;
    m->radius = 0;
    m->explode_me = false;
    m->launch = true;

    int32_t dx = m->x_dest - m->x_origin;
    int32_t dy = m->y_dest - m->y_origin;
    m->total_length = (int32_t)sqrtf((float)(dx * dx + dy * dy));
    if (m->total_length <= 0) m->total_length = 1;

    m->currentState = moving_st;
}

/*launch the plane missile*/
void missile_launch_plane(missile_t *m, coord_t x_orig, coord_t y_orig) {
    if (!m) return;

    m->type = MISSILE_TYPE_PLANE;
    m->x_origin = x_orig;
    m->y_origin = y_orig;
    m->x_dest = rand() % LCD_W;
    m->y_dest = LCD_H - 1;

    m->x_current = m->x_origin;
    m->y_current = m->y_origin;
    m->length = 0;
    m->radius = 0;
    m->explode_me = false;
    m->launch = true;

    int32_t dx = m->x_dest - m->x_origin;
    int32_t dy = m->y_dest - m->y_origin;
    m->total_length = (int32_t)sqrtf((float)(dx * dx + dy * dy));
    if (m->total_length <= 0) m->total_length = 1;

    m->currentState = moving_st;
}

/************************ Control & Status *************************/
/*set the bool explode to true*/
void missile_explode(missile_t *m) {
    if (!m) return;
    if (m->currentState == moving_st)
        m->explode_me = true;
}

/*get the position*/
void missile_get_pos(missile_t *m, coord_t *x, coord_t *y) {
    if (!m || !x || !y) return;
    *x = m->x_current;
    *y = m->y_current;
}

/*geth the type of missile*/
missile_type_t missile_get_type(missile_t *m) {
    if (!m) return MISSILE_TYPE_PLAYER;
    return m->type;
}

/*current motion*/
bool missile_is_moving(missile_t *m) {
    return m && (m->currentState == moving_st);
}

/*if its exloding*/
bool missile_is_exploding(missile_t *m) {
    return m && ((m->currentState == exploding_grow_st) || (m->currentState == exploding_shrink_st));
}

/*the missile is chill*/
bool missile_is_idle(missile_t *m) {
    return m && (m->currentState == idle_st);
}

/*it hit sumthin*/
bool missile_is_impacted(missile_t *m) {
    return m && (m->currentState == impact_st);
}

/*collision detected*/
bool missile_is_colliding(missile_t *m, coord_t x, coord_t y) {
    if (!m) return false;
    if (!missile_is_exploding(m)) return false;

    int32_t dx = x - m->x_current;
    int32_t dy = y - m->y_current;
    int32_t dist2 = dx * dx + dy * dy;
    int32_t r2 = m->radius * m->radius;

    return dist2 <= r2;
}

/************************ Tick Function *************************/
void missile_tick(missile_t *m) {
    if (!m) return;
    
    // ---------- State Transitions ----------
    switch (m->currentState) {
        case init_st:
            m->currentState = idle_st;
            break;

        case idle_st:
            if (m->launch)
                m->currentState = moving_st;
            break;

        case moving_st:
            if (m->explode_me) {
                m->currentState = exploding_grow_st;
            } else if (m->length >= m->total_length) {
                if (m->type == MISSILE_TYPE_PLAYER) {
                    m->currentState = exploding_grow_st;
                } else {
                    m->currentState = impact_st;
                }
            }
            break;

        case exploding_grow_st:
            if (m->radius >= CONFIG_EXPLOSION_MAX_RADIUS)
                m->currentState = exploding_shrink_st;
            break;

        case exploding_shrink_st:
            if (m->radius <= 0)
                m->currentState = impact_st;
            break;

        case impact_st:
            m->currentState = idle_st;
            m->launch = false;
            m->explode_me = false;
            m->radius = 0;
            m->length = 0;
            m->total_length = 0;
            m->x_current = m->x_origin;
            m->y_current = m->y_origin;
            break;

        default:
            break;
    }

    // ---------- State Actions ----------
    switch (m->currentState) {
        case init_st:
            break;
        case idle_st:
            break;

        case moving_st: {
            int32_t dx = m->x_dest - m->x_origin;
            int32_t dy = m->y_dest - m->y_origin;

            int32_t speed = (m->type == MISSILE_TYPE_PLAYER)
                            ? CONFIG_PLAYER_MISSILE_DISTANCE_PER_TICK
                            : CONFIG_ENEMY_MISSILE_DISTANCE_PER_TICK;

            m->length += speed;
            if (m->length > m->total_length)
                m->length = m->total_length;

            int32_t ratio = (m->length * THOUSAND) / m->total_length;
            m->x_current = m->x_origin + (dx * ratio) / THOUSAND;
            m->y_current = m->y_origin + (dy * ratio) / THOUSAND;

            // Draw missile trail
            color_t trail_color;
            if (m->type == MISSILE_TYPE_PLAYER) {
                trail_color = CONFIG_COLOR_PLAYER_MISSILE;
            } else if (m->type == MISSILE_TYPE_PLANE) {
                trail_color = CONFIG_COLOR_PLANE_MISSILE;
            } else {
                trail_color = CONFIG_COLOR_ENEMY_MISSILE;
            }

            lcd_drawLine(m->x_origin, m->y_origin, m->x_current, m->y_current, trail_color);
            break;
        }
        // explosion 
        case exploding_grow_st: {
            m->radius += CONFIG_EXPLOSION_RADIUS_CHANGE_PER_TICK;
            if (m->radius > CONFIG_EXPLOSION_MAX_RADIUS)
                m->radius = CONFIG_EXPLOSION_MAX_RADIUS;
            
            color_t exp_color;
            if (m->type == MISSILE_TYPE_PLAYER) {
                exp_color = CONFIG_COLOR_PLAYER_MISSILE;
            } else if (m->type == MISSILE_TYPE_PLANE) {
                exp_color = CONFIG_COLOR_PLANE_MISSILE;
            } else {
                exp_color = CONFIG_COLOR_ENEMY_MISSILE;
            }
            lcd_fillCircle(m->x_current, m->y_current, m->radius, exp_color);
            break;
        }
        // explosion action
        case exploding_shrink_st: {
            if (m->radius > CONFIG_EXPLOSION_RADIUS_CHANGE_PER_TICK)
                m->radius -= CONFIG_EXPLOSION_RADIUS_CHANGE_PER_TICK;
            else
                m->radius = 0;
            
            color_t exp_color;
            if (m->type == MISSILE_TYPE_PLAYER) {
                exp_color = CONFIG_COLOR_PLAYER_MISSILE;
            } else if (m->type == MISSILE_TYPE_PLANE) {
                exp_color = CONFIG_COLOR_PLANE_MISSILE;
            } else {
                exp_color = CONFIG_COLOR_ENEMY_MISSILE;
            }
            lcd_fillCircle(m->x_current, m->y_current, m->radius, exp_color);
            break;
        }

        case impact_st:
            lcd_fillCircle(m->x_current, m->y_current, CONFIG_EXPLOSION_MAX_RADIUS + 1, CONFIG_COLOR_BACKGROUND);
            lcd_drawLine(m->x_origin, m->y_origin, m->x_dest, m->y_dest, CONFIG_COLOR_BACKGROUND);
            break;

        default:
            break;
    }
}