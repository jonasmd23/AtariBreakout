#ifndef GAME_H_
#define GAME_H_

#include "ball.h"
#include "platform.h"
#include "brick.h"

// Global game objects
extern ball_t game_ball;
extern platform_t game_platform;
extern brick_grid_t game_bricks;


// Initialize the game control logic.
void game_init(void);

// Update the game control logic.
void game_tick(void);

#endif // GAME_H_
