
#include <stdint.h>

#define BIGX_BITS_PER_SAMPLE 8
#define BIGX_SAMPLE_RATE 24000
#define BIGX_SAMPLES 19000

extern const uint8_t bigx[BIGX_SAMPLES];
