#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "driver/gptimer.h"
#include "esp_log.h"
#include "hw.h"
#include "lcd.h"
#include "pin.h"
#include "watch.h"
#include "esp_timer.h"

// Constants to replace magic numbers
#define MILLIE 1000000
#define TENK 10000
#define SEC5 500

static const char *TAG = "lab03";

// Global variables used in ISR and main loop
volatile bool running = false;
volatile uint32_t timer_ticks = 0;
volatile int64_t isr_max = 0;
volatile int32_t isr_cnt = 0;

// this is my isr it is Called every 10ms when the timer alarm triggers. Also tracks ISR execution time for performance measurement.
static bool example_timer_on_alarm_cb(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx)
{
    int64_t start = esp_timer_get_time();
    // check if A is pressed 
    if (pin_get_level(HW_BTN_A) == 0) {
        running = true;
    }
    // check if b is pressed 
    if (pin_get_level(HW_BTN_B) == 0) {
        running = false;
    }
    // check if start is pressed 
    if (pin_get_level(HW_BTN_START) == 0) {
        running = false;
        timer_ticks = 0;
    }
    // if stopwatch is running, increment the timer
    if (running) {
        timer_ticks++;
    }
    int64_t finish = esp_timer_get_time();
    int64_t duration = finish - start;

    if (duration > isr_max) {
        isr_max = duration;
    }
    isr_cnt++;
    return false;
}

// Initializes hardware buttons, sets up the GPTimer for 10ms periodic interrupts, and enters an infinite loop where stopwatch ticks are updated and ISR performance is logged.
void app_main(void)
{
    int64_t start_pins, finish_pins;
    int64_t start_timer_cfg, finish_timer_cfg;
    int64_t start_log, finish_log;


    start_pins = esp_timer_get_time();
    pin_reset(HW_BTN_A);
    pin_input(HW_BTN_A, true);
    pin_reset(HW_BTN_B);
    pin_input(HW_BTN_B, true);
    pin_reset(HW_BTN_START);
    pin_input(HW_BTN_START, true);
    finish_pins = esp_timer_get_time();
    ESP_LOGI(TAG, "Pin configuration time: %lld microseconds", finish_pins - start_pins);

    start_timer_cfg = esp_timer_get_time();
    gptimer_handle_t gptimer = NULL;

    gptimer_config_t timer_config = {
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = MILLIE 
    };
    ESP_ERROR_CHECK(gptimer_new_timer(&timer_config, &gptimer));

    gptimer_alarm_config_t alarm_config = {
        .reload_count = 0,
        .alarm_count = TENK, 
        .flags.auto_reload_on_alarm = true,
    };
    ESP_ERROR_CHECK(gptimer_set_alarm_action(gptimer, &alarm_config));

    gptimer_event_callbacks_t cbs = {
        .on_alarm = example_timer_on_alarm_cb,
    };
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(gptimer, &cbs, NULL));
    ESP_ERROR_CHECK(gptimer_enable(gptimer));
    ESP_ERROR_CHECK(gptimer_start(gptimer));
    finish_timer_cfg = esp_timer_get_time();
    ESP_LOGI(TAG, "Timer configuration time: %lld microseconds", finish_timer_cfg - start_timer_cfg);

    start_log = esp_timer_get_time();
    ESP_LOGI(TAG, "Stopwatch update");
    finish_log = esp_timer_get_time();
    ESP_LOGI(TAG, "ESP_LOGI print time: %lld microseconds", finish_log - start_log);

    lcd_init();
    watch_init();

    // forever loop calls ticks and measures isr
    for (;;) {
        watch_update(timer_ticks);
        // Log max ISR duration every 500 ticks (~5 seconds)    
        if (isr_cnt >= SEC5) {
            ESP_LOGI(TAG, "Maximum ISR execution time over last 5 seconds: %lld microseconds", isr_max);
            isr_max = 0;
            isr_cnt = 0;
        }
    }
    }
