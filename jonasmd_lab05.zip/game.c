#include <stdio.h>  // NOLINT
#include "config.h"
#include "board.h"
#include "graphics.h"
#include "nav.h"
#include "com.h"
#include "game.h"

#include "hw.h"
#include "lcd.h"
#include "joy.h"
#include "pin.h"

#define FULL 9
#define FIRST 4
#define SECOND 0x0F

static int8_t current_player = X_m;



// States for the controller state machine.
enum gameControl_st {
	init_st,                
    new_game_st,
    wait_mark_st,
    mark_st,
    wait_restart_st
};
static enum gameControl_st currentState;

// Initialize the state machine.
void game_init() {
  currentState = init_st;
}

// Standard tick function.
void game_tick() {  
  static int8_t current_r = 1;
  static int8_t current_c = 1;
  uint8_t data;
  uint8_t rx_data;
  //Process state transitions first.
  switch(currentState) {
    case init_st:
        currentState = new_game_st;
      break;

    case new_game_st:
        graphics_drawMessage("Next Player: X", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
        currentState = wait_mark_st;
      break;

    case wait_mark_st:
        nav_get_loc(&current_r, &current_c);
        // Check if Button A is pressed and location is valid
        if ((board_get(current_r, current_c) == no_m) && (!pin_get_level(HW_BTN_A))) {
            data = (current_r << FIRST) | (current_c & SECOND);
            com_write(&data, sizeof(data));  // Pass address of data
            currentState = mark_st;
        }
        
        // Check if data was received
        if (com_read(&rx_data, sizeof(rx_data)) > 0){
            int8_t recv_r = (rx_data >> FIRST) & SECOND;
            int8_t recv_c = rx_data & SECOND;

            if (board_get(recv_r, recv_c) == no_m) {
                current_r = recv_r;
                current_c = recv_c;
                currentState = mark_st;
            }
        }
      break;

    case mark_st:
        if (board_winner(current_player)){
            graphics_drawMessage(current_player == X_m ? "X Wins! Press START to restart!" : "O Wins! Press START to restart!", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
            currentState = wait_restart_st;
        }else if (board_mark_count() == CONFIG_BOARD_SPACES){
            graphics_drawMessage("Draw Game! Press START to restart!", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
            currentState = wait_restart_st;
        }else{
            currentState = wait_mark_st;
            current_player = (current_player == X_m) ? O_m : X_m;            
        }
      break;

    case wait_restart_st:
        if (!pin_get_level(HW_BTN_START)){
            currentState = new_game_st;
            lcd_fillScreen(CONFIG_BACK_CLR);

        }
      break;

    default:
      printf("youre cooked bruv");
      break;
  }








  // Process state actions next.
  switch(currentState) {
    case init_st:
        break;

    case new_game_st:
        board_clear();
        graphics_drawGrid(CONFIG_GRID_CLR);
        current_player = X_m;
        nav_set_loc(current_r, current_c);
        while (com_read(&rx_data, sizeof(rx_data)) > 0){}
    break;

    case wait_mark_st:
      break;

    case mark_st:
        board_set(current_r, current_c, current_player);
        if (current_player == X_m){
            graphics_drawX(current_r, current_c, CONFIG_MARK_CLR);
            graphics_drawMessage("Next Player: O", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
        }else{
            graphics_drawO(current_r, current_c, CONFIG_MARK_CLR);
            graphics_drawMessage("Next Player: X", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
        }

      break;

    case wait_restart_st:
        current_c = 1;
        current_r = 1;
    break;

    default:
      printf("youre cooked bruv");
      break;
  }  
}

