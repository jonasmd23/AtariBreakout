#include <stdio.h>  // NOLINT
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "hw.h"
#include "lcd.h"
#include "net.h"
#include "com.h"
#include "graphics.h"
#include "config.h"

#define GROUP_ID 1
#define GROUP_WAIT 4000 

// init com
int32_t com_init(){
    int32_t ret;
    
    ret = net_init();
    if (ret) {
        printf("net_init() fail:%ld\n", ret);
        return ret;
    }
    
    ret = net_group_open(GROUP_ID);
    if (ret) {
        printf("net_group_open() fail:%ld\n", ret);
        return ret;
    }
    graphics_drawMessage("Waiting to join group...", CONFIG_MESS_CLR, CONFIG_BACK_CLR);
    vTaskDelay(pdMS_TO_TICKS(GROUP_WAIT));
    
    ret = net_group_close();
    if (ret) {
        printf("net_group_close() fail:%ld\n", ret);
        return ret;
    }
    
    return 0;
}

// deinit com
int32_t com_deinit(){
    return net_deinit();
}

// Non-blocking send
int32_t com_write(const void *buf, uint32_t size){
    int32_t ret = net_send(NULL, buf, size, 0);
    if (ret < 0){
        return ret;
    }
    return ret;
}

// Non-blocking read
int32_t com_read(void *buf, uint32_t size){
    uint8_t src[NET_ALEN];
    int32_t ret = net_recv(src, buf, size, 0); 
    if (ret <= 0){
        return ret;
    }
    return ret; 
}